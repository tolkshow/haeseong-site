export default function Footer() {
  return (
    <footer className="bg-gray-100 text-center text-sm text-gray-600 py-6 mt-20">
      ⓒ 2025 해성인력 | 충남 당진시 서부로 85-16 | 대표전화: 010-7537-5154
    </footer>
  );
}