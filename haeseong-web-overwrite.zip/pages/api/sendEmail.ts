import type { NextApiRequest, NextApiResponse } from "next";
import emailjs from "@emailjs/nodejs";

const SERVICE_ID = "your_service_id";
const TEMPLATE_ID = "your_template_id";
const PUBLIC_KEY = "your_public_key";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).end("Method Not Allowed");

  const { name, phone, position } = req.body;

  try {
    const response = await emailjs.send(SERVICE_ID, TEMPLATE_ID, {
      name,
      phone,
      position,
    }, {
      publicKey: PUBLIC_KEY,
    });

    return res.status(200).json({ success: true, result: response });
  } catch (error) {
    console.error("Email sending failed:", error);
    return res.status(500).json({ success: false, error: "Email send failed" });
  }
}